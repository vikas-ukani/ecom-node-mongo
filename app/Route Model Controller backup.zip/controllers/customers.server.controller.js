'use strict';

/**
 * Module dependencies.
 */
var _ = require('lodash'),
	errorHandler = require('./errors.server.controller');

exports.listCustomers = function(req, res) {

};

exports.getCustomer = function(req, res) {

};